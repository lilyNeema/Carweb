function addToCart(carName, price) {
    // Add the car to the cart (this is a simple implementation)
    let cartContainer = document.getElementById('cart-container');
    let newItem = document.createElement('div');
    newItem.innerHTML = `<p>${carName} - $${price}</p>`;
    cartContainer.appendChild(newItem);
}
